# TODO --watch mode
buble -i ./src -o ./esmodule --no modules --yes dangerousForOf --target ie:11 --objectAssign "Object.assign" -m inline
