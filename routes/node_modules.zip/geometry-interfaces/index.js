'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DOMPointReadOnly = exports.DOMPoint = exports.DOMMatrixReadOnly = exports.DOMMatrix = undefined;

var _DOMMatrix = require('./DOMMatrix');

var _DOMMatrix2 = _interopRequireDefault(_DOMMatrix);

var _DOMMatrixReadOnly = require('./DOMMatrixReadOnly');

var _DOMMatrixReadOnly2 = _interopRequireDefault(_DOMMatrixReadOnly);

var _DOMPoint = require('./DOMPoint');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let _global = null;

// browser
if (typeof window != 'undefined') {
    _global = window;
} else if (typeof global != 'undefined') {
    _global = global;
}

if (_global) {
    _global.DOMMatrix = _DOMMatrix2.default;
    _global.DOMMatrixReadOnly = _DOMMatrixReadOnly2.default;
    _global.DOMPoint = _DOMPoint.DOMPoint;
    _global.DOMPointReadOnly = _DOMPoint.DOMPointReadOnly;
}

exports.DOMMatrix = _DOMMatrix2.default;
exports.DOMMatrixReadOnly = _DOMMatrixReadOnly2.default;
exports.DOMPoint = _DOMPoint.DOMPoint;
exports.DOMPointReadOnly = _DOMPoint.DOMPointReadOnly;
//# sourceMappingURL=index.js.map