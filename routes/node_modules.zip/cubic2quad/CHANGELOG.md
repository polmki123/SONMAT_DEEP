1.1.1 / 2017-05-08
------------------

- Fix sorting in `solveInflections`, #4.


1.1.0 / 2016-10-26
------------------

- Support curves with inflection point.


1.0.0 / 2015-10-27
------------------

- First release.
