var convert = require('./convert'),
    func = convert('sortedIndexOf', require('../sortedIndexOf'));

func.placeholder = require('./placeholder');
module.exports = func;
