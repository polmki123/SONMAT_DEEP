module.exports = require('./negate');
