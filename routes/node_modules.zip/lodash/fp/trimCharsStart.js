var convert = require('./convert'),
    func = convert('trimCharsStart', require('../trimStart'));

func.placeholder = require('./placeholder');
module.exports = func;
