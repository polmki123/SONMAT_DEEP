var convert = require('./convert'),
    func = convert('pullAllWith', require('../pullAllWith'));

func.placeholder = require('./placeholder');
module.exports = func;
